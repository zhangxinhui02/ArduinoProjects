var searchData=
[
  ['core_20register_20access',['Core Register Access',['../group___core___register__gr.html',1,'']]]
];
