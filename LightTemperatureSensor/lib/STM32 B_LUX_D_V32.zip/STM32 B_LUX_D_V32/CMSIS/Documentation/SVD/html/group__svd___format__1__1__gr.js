var group__svd___format__1__1__gr =
[
    [ "Extensions to the Device Section", "group__device_section_extensions__gr.html", null ],
    [ "CPU Section (New)", "group__cpu_section__gr.html", null ],
    [ "Extensions to the Peripheral Section", "group__peripheral_section_extensions__gr.html", null ],
    [ "Cluster Level (New)", "group__cluster_level__gr.html", null ],
    [ "Extensions to the Register Section", "group__register_section_extensions__gr.html", null ]
];