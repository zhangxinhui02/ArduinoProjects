# LiquidCrystal_SoftI2C
LiquidCrystal Arduino library for the Soft I2C LCD displays
