#include <Wire.h>

#include "SGP30.h"
//http://rtrobot.org

SGP30::SGP30()
{
	
}

boolean SGP30::begin(void)
{
	Wire.begin();
	_i2caddr = SGP30_ADDRESS;
	Wire.begin();
	
	if(!get_serial_id())
		return false;
	
	if(!get_feature_set_version())
		return false;
	
	if(!init_air_quality())
		return false;
	
	return true;
}

boolean SGP30::get_serial_id(void)
{
	uint8_t buf[2]={0x36,0x82};
	return readCommand(buf,2,Serial_ID,3);
}

boolean SGP30::get_feature_set_version(void)
{
	uint8_t buf[2]={0x20,0x2f};
	uint16_t tmp[1];
	return readCommand(buf,2,tmp,1);
}

boolean SGP30::init_air_quality(void)
{
	uint8_t buf[2]={0x20,0x03};
	return readCommand(buf, 2);
}

boolean SGP30::set_iaq_baseline(uint32_t iaq_baseline) 
{
	uint8_t buf[8];
	buf[0]=0x20;
	buf[1]=0x1e;
	buf[2]=iaq_baseline>>24;
	buf[3]=((iaq_baseline & 0x00FF0000)>>16)&0xFF;
	uint8_t tmp[2]={buf[2],buf[3]};
	buf[4]=common_generate_crc(tmp, 2);
	buf[5]=((iaq_baseline & 0x0000FF00)>>8)&0xFF;
	buf[6]=iaq_baseline & 0xFF;
	tmp[0]=buf[5];
	tmp[1]=buf[6];
	buf[7]=common_generate_crc(tmp, 2);
	return readCommand(buf, 8);
}

boolean SGP30::get_iaq_baseline(uint32_t *iaq_baseline) 
{
	uint8_t buf[2];
	buf[0] = 0x20;
	buf[1] = 0x15;
	uint16_t tmp[2];
	if (!readCommand(buf, 2, tmp, 2))
		return false;
	*iaq_baseline = (tmp[0]<<16) | tmp[1];
	return true;
}

boolean SGP30::set_tvoc_baseline(uint16_t tvoc_baseline) 
{
	uint8_t buf[8];
	buf[0]=0x20;
	buf[1]=0xb3;
	buf[2]=tvoc_baseline>>8;
	buf[3]=tvoc_baseline & 0xFF;
	uint8_t tmp[2]={buf[2],buf[3]};
	buf[4]=common_generate_crc(tmp, 2);
	return readCommand(buf, 5);
}

boolean SGP30::get_tvoc_baseline(uint16_t *tvoc_baseline) 
{
	uint8_t buf[2];
	buf[0] = 0x20;
	buf[1] = 0x77;
	uint16_t tmp[2];
	if (!readCommand(buf, 2, tmp, 1))
		return false;
	*tvoc_baseline=tmp[0];
	return true;
}

boolean SGP30::set_absolute_humidity(float temperature, float humidity)
{
	uint32_t absolute_humidity=216.7 * (((float)(temperature/100.0) * 6.112 * exp((17.62 * temperature) / (243.12 + temperature))) / (273.15 + temperature)) * 1000.0;
	if (absolute_humidity > 256000)
		return false;
	uint16_t ah_scaled = (uint16_t)(((uint64_t)absolute_humidity * 256 * 16777) >> 24);
	uint8_t buf[5];
	buf[0] = 0x20;
	buf[1] = 0x61;
	buf[2] = ah_scaled >> 8;
	buf[3] = ah_scaled & 0xFF;
	uint8_t tmp[2]={buf[2],buf[3]};
	buf[4] = common_generate_crc(tmp, 2);
	return readCommand(buf, 5);
}

boolean SGP30::measure_air_quality(void)
{
	uint8_t buf[2];
	uint16_t tmp[2];
	buf[0]=0x20;
	buf[1]=0x08;
	
	if(!readCommand(buf, 2, tmp , 2))
		return false;
	
	TVOC = tmp[1];
	ECO2 = tmp[0];
	return true;
}

boolean SGP30::measure_raw_signals(void)
{
	uint8_t buf[2];
	uint16_t tmp[2];
	buf[0]=0x20;
	buf[1]=0x50;
	
	if(!readCommand(buf, 2, tmp , 2))
		return false;
	
	H2_RAW = tmp[1];
	ETHANOL_RAW = tmp[0];
	return true;
}

boolean SGP30::readCommand(uint8_t *reg, uint8_t length, uint16_t *redata, uint8_t redata_length)
{
	Wire.beginTransmission(_i2caddr);
	for(uint8_t i=0; i<length; i++)
	    Wire.write(reg[i]);
	Wire.endTransmission(false);
	while (Wire.requestFrom(_i2caddr, (uint8_t)(redata_length*3)) != redata_length*3);
	
	uint8_t buf[redata_length*3];
	for(uint8_t i=0; i<redata_length*3; i++)
	{
		buf[i]=Wire.read();
		if((i+1)%3 == 0)
		{
			uint8_t tmp[2]={buf[i-2],buf[i-1]};
			if(common_generate_crc(tmp,2)!=buf[i])
				return false;
		}
	}
	for(uint8_t i=0; i<redata_length; i++)
		redata[i]=(buf[i * 3]<<8)|buf[i * 3 + 1];
	return true;
}

uint8_t SGP30::common_generate_crc(uint8_t *data, uint16_t count) 
{
	uint16_t current_byte;
	uint8_t crc = SGP30_CRC8_INIT;
	uint8_t crc_bit;

	/* calculates 8-Bit checksum with given polynomial */
	for (current_byte = 0; current_byte < count; ++current_byte) 
	{
		crc ^= (data[current_byte]);
		for (crc_bit = 8; crc_bit > 0; --crc_bit) 
		{
            		if (crc & 0x80)
				crc = (crc << 1) ^ SGP30_CRC8_POLYNOMIAL;
			else
				crc = (crc << 1);
		}
	}
	return crc;
}
