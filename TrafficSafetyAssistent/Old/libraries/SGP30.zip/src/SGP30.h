#ifndef SGP30_H
#define SGP30_H
//http://rtrobot.org

#include <Arduino.h>

#define SGP30_ADDRESS	0x58
#define SGP30_CRC8_INIT	0xFF
#define SGP30_CRC8_POLYNOMIAL	0x31


class SGP30 {
public:
	SGP30();
	uint16_t Serial_ID[3];
	uint16_t TVOC;
	uint16_t ECO2;
	uint16_t H2_RAW;
	uint16_t ETHANOL_RAW;
	boolean begin(void);
	boolean get_serial_id(void);
	boolean get_feature_set_version(void);
	boolean measure_air_quality(void);
	boolean measure_raw_signals(void);
	boolean init_air_quality(void);
	boolean set_iaq_baseline(uint32_t iaq_baseline);
	boolean get_iaq_baseline(uint32_t *iaq_baseline);
	boolean set_tvoc_baseline(uint16_t tvoc_baseline);
	boolean get_tvoc_baseline(uint16_t *tvoc_baseline);
	boolean set_absolute_humidity(float temperature, float humidity);

private:
	uint8_t _i2caddr;
	boolean readCommand(uint8_t *reg, uint8_t length, uint16_t *redata=NULL, uint8_t redata_length=0);
	void writeCommand(uint8_t reg, uint8_t *cmd, uint8_t length);
	uint8_t common_generate_crc(uint8_t *data, uint16_t count);
};


#endif 